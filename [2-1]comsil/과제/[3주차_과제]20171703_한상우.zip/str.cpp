#include <iostream>
#include <string.h>
#include "str.h"
using namespace std;


// leng은 string의 길이
Str::Str(int leng)
{
	if (leng < 0)
	{
		cout << "Error!! :: not an proper length!\n" << endl;
	}

	str = new char[leng + 1];

	for (int i = 0; i < leng; i++)
	{
		str[i] = ' ';
	}

	str[leng] = '\0';

	len = leng;
}

//neyoung은 초기화 할 내용이 들어감
Str::Str(char *neyong)
{
	if (neyong == NULL)
	{
		cout << "Error!! : input is a null string!\n" << endl;
	}
	else
	{
		len = strlen(neyong);
		str = new char[len + 1]; //꼭 len+1
		strcpy(str, neyong);
	}
}

// 소멸자
Str::~Str()
{
	delete[] str;
}

// string의 길이를 리턴하는 함수. 
int Str::length(void)
{
	return len; //같은 클래스의 맴버이기 때문에 접근 가능
}

// string의 내용을 리턴하는 함수.
char * Str::contents(void)
{
	return str; //같은 클래스의 맴버이기 때문에 접근 가능
}

// a의 내용과 strcmp, (string)
int Str::compare(class Str& a)
{
	return strcmp(str, a.str);
}

// a의 내용과 strcmp, (char)
int Str::compare(char *a)
{
	return strcmp(str, a);
}

// string의 값을 대입.
void Str::operator=(char * a)
{
	if (a == NULL)
	{
		cout << "Error!! : input is a null string!\n" << endl;
	}
	else
	{
		len = strlen(a);
		str = new char[len + 1]; //꼭 len+1
		strcpy(str, a);
	}
}

// Str의 내용을 대입.
void Str::operator=(class Str& a)
{
	len = a.len;
	str = new char[len + 1];
	strcpy(str, a.contents());
}
//class Str&a와 char *a의 차이를 조심하자