#include "Header.h"

void Print_array(int* array)
{
	for (int i = 0; i < 10; i++)
	{
		printf("%d ", array[i]);
	}

	printf("\n");
}