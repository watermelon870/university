#include "Header.h"

int main(void)
{
	int T = 0;
	int ts1 = 10, ts2 = 1;

	int *array = (int*)malloc(sizeof(int) * 9);

	int *N = (int*)malloc(sizeof(int)*T);

	printf("set the number of test case : ");
	scanf("%d", &T);

	for (int i = 0; i < T; i++)
	{
		printf("set the pages of the book : ");
		scanf("%d", &N[i]);
	}

	for (int i = 0; i < T; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			array[j] = 0;
		}
		Find_array(array, N[i], ts1, ts2);
		Print_array(array);
	}

	return 0;
}