#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>


void Print_array(int *array);
void Find_array(int* array, int N, int ts1, int ts2);