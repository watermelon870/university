#include "Header.h"

int n = 1;
int temp = 11;

void Find_array(int* array, int N, int ts1, int ts2)
{
	n = ts2;

	while (n <= N)
	{
		temp = n % ts1 / ts2;
		array[temp]++;
		n++;
	}

	if (N % ts1 != N)
	{
		ts1 = ts1 * 10;
		ts2 = ts2 * 10;
		n = ts2;
		Find_array(array, N, ts1, ts2);
	}
}