#include <iostream>
using namespace std;
#include "RangeArray.h"

RangeArray::RangeArray(int i,int j):Array(j-i+1)
{
	low = i; //-1
	high = j; //5
}

RangeArray::~RangeArray() //�Ҹ���; �Ҵ�� �޸� ����
{

}

int RangeArray::baseValue()
{
	return low;
}
int RangeArray::endValue()
{
	return high;
}
int& RangeArray::operator [](int i)
{
	static int tmp;
	if (low > i || i > high)
	{
		cout << "Error!! :: not a proper index!" << endl;
		return tmp;
	}

	return Array::operator [](i-low);
}
int RangeArray::operator [](int i) const
{
	if (low > i || i > high)
	{
		cout << "Error!! :: not a proper index!" << endl;
		return 0;
	}

	return Array::operator [](i-low);
}
