#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	int data;
	nptr link;
}NODE;

void Insert(nptr head, int data)
{
	nptr last = head;
	while (last->link != NULL)
	{
		last = last->link;
	}

	nptr newNode = (nptr)malloc(sizeof(NODE));
	newNode->data = data;
	newNode->link = NULL;
	last->link = newNode;

	//printf("data inserted front! \n");
}


void PrintAll(nptr head)
{
	nptr curr = head;

	if (curr->link == NULL)
	{
		printf("Empty");
	}
	else
	{
		while (curr->link != NULL)
		{
			curr = curr->link;



			printf("%d ", curr->data);
		}
	}
	printf("\n");
}

void Delete(nptr head)                          //delete이렇게 하자!!!!
{
	nptr ptr = head->link;
	head->link = ptr->link;

	free(ptr);
}

void freeAll(nptr head)
{
	nptr curr = head;
	nptr prev;
	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}
	free(curr);
}

int main()
{
	nptr head = (nptr)malloc(sizeof(NODE));
	head->data = NULL;
	head->link = NULL;

	int A[10] = { 3, 9, 8, 2, 5, 10, 7, 1, 4, 6 };

	for (int i = 0; i < 10; i++)
	{
		Insert(head, A[i]);
	}

	PrintAll(head);

	for (int i = 0; i < 10; i++)
	{
		Delete(head);
		PrintAll(head);
	}

	freeAll(head);

	return 0;
}
