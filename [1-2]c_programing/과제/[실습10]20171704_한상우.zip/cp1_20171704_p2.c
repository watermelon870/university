#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	int st_id;
	char st_name[30];
	nptr link;
}Node;

nptr head;

void create_Node(int id, char *name)         //앞 과제의 Insert와 같은 역할
{
	nptr newNode = (nptr)malloc(sizeof(Node));

	if (head == NULL)                        //head가 NULL인 상태일 경우
	{
		head = (nptr)malloc(sizeof(Node));
		head->link = NULL;

	//	printf("head malloc \n");

	}
	else
	{
	}
	                                         //head가 NULL이 아닌 경우
	nptr last = head;
	while (last->link != NULL)
	{
		last = last->link;
	}

	newNode->st_id = id;
	strcpy(newNode->st_name, name);
	last->link = newNode;          //항상 l값으로 link를
	newNode->link = NULL;

	//printf("data inserted! \n");
}

/*
void PrintAll()
{
	nptr curr = head->link;              //얘네는 malloc해줄 필요 없다, 그리고 만약에 해주면 free는 어떻게 하게
	while (curr != NULL)
	{
		printf("%d / %s \n", curr->st_id, curr->st_name);
		curr = curr->link;
	}
}
*/

void freeAll()
{
	nptr curr = head;
	nptr prev;
	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}

	free(curr);
}

int main()
{
	int count = 0;

	FILE *fp = fopen("input.txt", "r");

	char buffer[100][50];                          //파일에서부터 총 100줄, 줄마다 50글자씩 가져올 수 있는 buffer생성

	for (int i = 0; i < 100; i++)
	{
		fgets(buffer[i], sizeof(char) * 50, fp);
		if (strncmp(buffer[i], "20", 2) != 0)
		{
			break;
		}
		count++;
		
		char temp_idc[10];
		int temp_idi;
		char temp_name[30];

		strcpy(temp_idc, strtok(buffer[i], "/"));
		temp_idi = atoi(temp_idc);
		strcpy(temp_name, strtok(NULL, "/"));

		create_Node(temp_idi, temp_name + 1);

		//printf("<%d / %s> \n", atoi(temp_idc), temp_name);
	}

	
	

	/*
	create_Node(20171704, "HAN SANG");
	create_Node(20171705, "HAN SANG w");
	*/
	
	nptr curr = head->link;            
	while (curr != NULL)
	{
		printf("%d / %s", curr->st_id, curr->st_name);
		curr = curr->link;
	}
	
	//출력은 메인함수에서
	
	freeAll();
	free(curr);
	return 0;
}
