#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	int data;
	nptr link;
}NODE;
//★★★★linked list 선언하는 법 알아보기

/*
void Insert(NODE* head, int data)
{
	NODE* curr = (NODE *)malloc(sizeof(NODE));
	curr->data = data;
	curr = head->link;
	curr->link = NULL;

	printf("data inserted! \n");
}
*/ //이 거지같은 함수는 일단 addNodeToFirst를 실행하고 curr에 NULL값을 집어넣어서 망한 함수다


void Insert(NODE* head, int data)
{
	NODE* last = head;
	while(last->link != NULL)       //last->link로 해줘야 한다
	{
		last = last->link;
	}
	//생각한 것과 같게 NODE2개가 필요하다
	NODE* newNode = (NODE *)malloc(sizeof(NODE));
	newNode->data = data;
	last->link = newNode;          //항상 l값으로 link를
	newNode->link = NULL;

	//printf("data inserted! \n");
}


void PrintAll(NODE* head)
{
	NODE* curr = head->link;              //얘네는 malloc해줄 필요 없다, 그리고 만약에 해주면 free는 어떻게 하게
	while(curr != NULL)
	{
		printf("%d ", curr->data);
		curr = curr->link;
	}

	printf("\n");
}


void freeAll(NODE* head)
{
	NODE *curr = head;
	NODE *prev;
	while(curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}

	free(curr);
}

int main()
{
	NODE* head = (NODE *)malloc(sizeof(NODE));
	head->link = NULL;

	int A[10] ={ 3, 9, 8, 2, 5, 10, 7, 1, 4, 6 };

	for(int i = 0; i < 10; i++)
	{
		Insert(head, A[i]);
	}

	
	PrintAll(head);
	
	freeAll(head);

	return 0;
}
