#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	char data;
	nptr link;
}NODE;

nptr head;

void PrintList()
{
	nptr curr = head;

	while (curr->link != NULL)
	{
		curr = curr->link;
		printf("%c", curr->data);
	}
	printf("\n");
}

void DeleteNodeAtFront()
{
	nptr newNode = head->link;					   //기준 노드의 다음 노드주소를 newNode에 저장
	head->link = newNode->link;					   //기준 노드의 다음 노드에 삭제할 노드의 다음 노드를 지정

	free(newNode);                                 //노드 메모리 해제

	//printf("node delete at front! \n");
}

void DeleteNodeAtBack()
{
	nptr last = head;
	nptr prev;
	while (last->link != NULL)
	{
		prev = last;
		last = last->link;
	}

	free(last);
	prev->link = NULL; 
	//앞에것 지우는것보다 조금 더 편하다!
	//printf("node delete back! \n");
}

void InsertNodeAtFront(char data)
{
	nptr newNode = (nptr)malloc(sizeof(NODE));
	newNode->data = data;
	newNode->link = head->link;
	head->link = newNode;

	//printf("data inserted front! \n");
}

void InsertNodeAtBack(char data)
{
	nptr last = head;
	while (last->link != NULL)
	{
		last = last->link;
	}

	nptr newNode = (nptr)malloc(sizeof(NODE));
	newNode->data = data;
	newNode->link = NULL;
	last->link = newNode;

	//printf("data inserted back! \n");
}

void freeAll()
{
	nptr curr = head;
	nptr prev;
	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}
	free(curr);
}

int main()
{
	head = (nptr)malloc(sizeof(NODE));
	head->link = NULL;

	InsertNodeAtFront('n');
	InsertNodeAtFront('e');
	InsertNodeAtFront('p');
	InsertNodeAtBack('l');
	InsertNodeAtFront('o');
	InsertNodeAtBack('a');
	InsertNodeAtBack('b');
	PrintList();
	DeleteNodeAtFront();
	DeleteNodeAtBack();
	DeleteNodeAtBack();
	DeleteNodeAtBack();
	PrintList();

	freeAll();

	return 0;
}
