#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	char data;
	nptr link;
}NODE;

nptr head;

void InsertNodeAtFront(char a)
{
	nptr curr = (nptr)malloc(sizeof(NODE));

	curr->data = a;
	curr->link = head->link;
	head->link = curr;

	//printf("inserted front!\n");
}

void InsertNodeAtBack(char b)
{
	nptr last = head;
	while (last->link != NULL)
	{
		last = last->link;
	}

	nptr newNode = (nptr)malloc(sizeof(NODE));
	newNode->data = b;
	newNode->link = NULL;
	last->link = newNode;

	//printf("inserted back! \n");
}

void PrintList()
{
	nptr curr = head;

	while (curr->link != NULL)
	{
		curr = curr->link;
		printf("%c", curr->data);
	}
	printf("\n");
}

void freeAll()
{
	nptr curr = head;
	nptr prev;

	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}
	free(curr);
}

int main()
{
	head = (nptr)malloc(sizeof(NODE));
	head->link = NULL;

	InsertNodeAtFront('p');
	InsertNodeAtFront('p');
	InsertNodeAtFront('a');
	InsertNodeAtBack('l');
	InsertNodeAtBack('e');

	PrintList();

	freeAll();

	return 0;
}
