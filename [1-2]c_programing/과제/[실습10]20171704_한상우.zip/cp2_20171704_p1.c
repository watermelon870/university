#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* nptr;
typedef struct node {
	int data;
	nptr link;
}NODE;

void Insert(nptr head, int data)
{
	nptr curr = (nptr)malloc(sizeof(NODE));
	curr->data = data;
	curr->link = head->link;
	head->link = curr;

	//printf("data inserted!\n");

}

void PrintAll(nptr head)
{
	nptr curr = head;

	while (curr->link != NULL)
	{
		curr = curr->link;
		printf("%d ", curr->data);
	}

	printf("\n");
}

void freeAll(nptr head)
{
	nptr curr = head;
	nptr prev;

	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}

	free(curr);
}

int main()
{
	nptr head = (nptr)malloc(sizeof(NODE));
	head->link = NULL;

	int A[10] = { 3, 9, 8, 2, 5, 10, 7, 1, 4, 6 };

	for (int i = 0; i < 10; i++)
	{
		Insert(head, A[i]);
	}

	PrintAll(head);

	freeAll(head);

	return 0;
}
