#include <stdio.h>

int find_roomX(int H, int N)
{
	int i = 1;
	int divi;
	divi = N / H;
	
	if (divi * H == N) {
		return H;
	}
	else {
		while (1) {
			if ((divi * H) + i == N) {
				break;
			}
			i++;
		}
		return i;
	}
}

int find_roomY(int H, int N)
{
	int i = 1;
	while (1) {
		if (N - (i*H) <= 0) {
			break;
		}
		i++;
	}

	return i;
}
int main()
{
	int H, W, N;
	int arr[100][100];
	int X = 0, Y = 0;

	scanf("%d %d %d", &H, &W, &N);

	for (int w = 0; w < W; w++) {
		for (int h = H - 1; h >= 0; h--) {
			*(*(arr + h) + w) = (100 * (H - h)) + (w + 1);
		}
	}



	printf("%d \n", (find_roomX(H, N) * 100) + find_roomY(H, N));

	return 0;
}
