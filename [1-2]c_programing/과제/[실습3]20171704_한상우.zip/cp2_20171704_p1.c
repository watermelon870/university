#include <stdio.h>

void swap(int *a, int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void sort(int *a, int m)
{
	for (int j = m-1; j > 0; j--) {
		for (int i = 1; i < m; i++)
		{
			if (*(a + i - 1) > *(a + i))
			{
				swap(a + i - 1, a + i);
			}
		}
	}
}

void print_array(int *a, int m)
{
	for (int i = 0; i < m; i++)
	{
		printf("%d ", *(a + i));
	}
	printf("\n");
}

void all_sort(int a[][100], int n, int m)
{
	for (int j = 0; j < n; j++)
	{
		sort(*(a+j), m);
	}
}

void print_all_array(int a[][100], int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			printf("%d ", *(*(a + i) + j));
			if (j == m - 1)
			{
				printf("\n");
			}
		}
	}

}

int main()
{
	int N, M;
	int a[100][100];

	scanf("%d %d", &N, &M);

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++)
		{
			scanf("%d", *(a + i) + j);
		}
	}

	all_sort(a, N, M);
	print_all_array(a, N, M);
	
	return 0;
}
