#include<stdio.h>

void swap(int *a, int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void sort(int *a, int m)
{
	for (int i = m - 1; i > 0; i--)
	{
		for (int j = 1; j < m; j++)
		{
			if (*(a + j - 1) > *(a + j))
			{
				swap(a + j - 1, a + j);
			}
		}
	}
}

void all_sort(int a[][100], int n, int m)
{
	for (int i = 0; i < n; i++) //
	{
		sort(*(a + i), m);
	}
}

int binary_search(int *a, int* endPtr, int key, int **findPtr) //1차원에 대해서
{
	int *firstPtr;
	int *midPtr;
	int *lastPtr;

	firstPtr = a;
	lastPtr = endPtr;

	while (firstPtr <= lastPtr)
	{
		midPtr = firstPtr + (lastPtr - firstPtr) / 2; //
		if (key > *midPtr) // 큰쪽으로 반 보기
		{
			firstPtr = midPtr + 1;
		}
		else if (key < *midPtr) // 작은쪽으로 반 보기
		{
			lastPtr = midPtr - 1;
		}
		else //찾았다! 나오자!
		{
			firstPtr = lastPtr + 1;
		}
	}

	*findPtr = midPtr;

	return (key == *midPtr);
}

int all_binary_search(int a[][100], int n, int m, int key, int **findPtr)
{
	int *endPtr = 0;

	for (int i = 0; i < n; i++)
	{
		endPtr = &a[i][m - 1]; //endPtr 설정

		if (binary_search(*(a + i), endPtr, key, findPtr))
		{
			return 1;
			break;
		}
		if (i == n - 1)
		{
			return 0;
		}
	}

}

int main()
{
	int N, M, K;
	int a[100][100];
	int *findPtr = 0;
	int *endPtr = 0;

	scanf("%d %d %d", &N, &M, &K);

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++)
		{
			scanf("%d", (*(a + i) + j));
		}
	}

	all_sort(a, N, M);

	printf("%d \n", all_binary_search(a, N, M, K, &findPtr));

	if (all_binary_search(a, N, M, K, &findPtr) == 1)
	{
		printf("%p \n", findPtr);
	}


	return 0;
}
