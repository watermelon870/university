#include <stdio.h>

void scanarr(int a[100][100], int N)
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			scanf("%d", (*(a + i) + j));
		}
	}
}

void printarr(int a[100][100], int N)
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			printf("%d ", *(*(a + i) + j));
			if (j == N - 1)
			{
				printf("\n");
			}
		}
	}
}

void mat_mul(int a[100][100], int b[100][100], int c[100][100], int N)
{
	int i, j, k;

	for (i = 0; i < N; i++) 
	{
		for (j = 0; j < N; j++) 
		{
			*(*(c + i) + j) = 0;
			for (k = 0; k < N; k++)
			{
				*(*(c + i) + j) += *(*(a + i) + k) * *(*(b + k) + j);
			}
		}
	}

}

int main()
{
	int N = 0;
	int a[100][100];
	int b[100][100];
	int c[100][100];

	scanf("%d", &N);

	scanarr(a, N);
	scanarr(b, N);

	mat_mul(a, b, c, N);

	printarr(c, N);

	return 0;
}
