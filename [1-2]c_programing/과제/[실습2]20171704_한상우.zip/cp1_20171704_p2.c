#include <stdio.h>

void* f(void*pa, void*pb, int option)
{
	if (option == 0) {
		if (*(int *)pa >= *(int *)pb) {
			*(int *)pa = *(int *)pb;
		}
	}
	else if (option == 1) {
		if (*(float *)pa >= *(float *)pb) {
			*(float *)pa = *(float *)pb;
		}
	}
	else if (option == 2) {
		if (*(double *)pa >= *(double *)pb) {
			*(double *)pa = *(double *)pb;
		}
	}

}

int main()
{
	int option;

	scanf("%d", &option);

	int a, b;
	float fa, fb;
	double da, db;
	void *pa, *pb, *ans;

	if (option == 0) {
		scanf("%d %d", &a, &b);
		pa = &a; 
		pb = &b;
		f(pa, pb, option);
		printf("%d \n", *(int *)pa);
	}
	else if (option == 1) {
		scanf("%f %f", &fa, &fb);
		pa = &fa;
		pb = &fb;
		f(pa, pb, option);
		printf("%f \n", *(float *)pa);
	}
	else if (option == 2) {
		scanf("%lf %lf", &da, &db);
		pa = &da;
		pb = &db;
		f(pa, pb, option);
		printf("%lf \n", *(double *)pa);
	}

	return 0;
}
