#include <stdio.h>

void shift_right(int*a) 
{
	int t1 = 0, t2 = 0;

	t2 = *(a + 9);

	for (int i = 0; i < 9; i++) {
		t1 = *(a + 8 - i);
		*(a + 9 - i) = t1;
	}

	*a = t2;
}  //오른쪽으로 한칸 이동하는 함수
 
void shift_n_right(int*a, int n)
{
	for (int i = 0; i < n; i++) {
		shift_right(a);
	}

}//위 함수를 n번 반복하게 만듦

void print_array(int*a)
{
	for (int i = 0; i <= 9; i++) {
		printf("%d ", *(a + i));
	}
	printf("\n");
}//재배열된 array 출력

int main()
{
	int a[10] = { 1, 2, 3, 4, 5 ,6 ,7 ,8, 9, 10 };

	int n;
	scanf("%d", &n);
	n = n % 10;

	shift_n_right(a, n);
	print_array(a);

	return 0;
}
