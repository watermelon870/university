#include<stdio.h>

int is_prime(int **a)
{
	int i = 0;
	int last = **a / 2;
	if (**a <= 1) {
		return 0;
	}
	else{ 

		for (i = 2; i <= last; i++) {
			if ((**a % i) == 0) {
				return 0;
			}
		}
		return 1;
	}

}

int main()
{
	int a;
	int *pa = &a;
	int **ppa = &pa;

	scanf("%d", pa);

	printf("%d \n", is_prime(ppa));

	return 0;
}
