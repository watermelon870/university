#include <stdio.h>
#include <stdlib.h>

void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void bubblesort(int *a, int n)
{
	for (int j = 0; j < n - 1; j++)
	{
		for (int i = 1; i < n; i++)
		{
			if (*(a + i - 1) > *(a + i))
			{
				swap((a + i - 1), (a + i));
			}
		}
	}
}

void double_double(int **a, int *size)
{
	int j = 0;
	int start = *size;
	int end = 0;

	*size = 2 * (*size);

	end = *size;

	*a = (int *)realloc(*a, end * sizeof(int));

	for (int i = start; i < end; i++)
	{
		*(*a + start + j) = *(*a + j) * 2;  //여기서 한참 걸렸다 조심하자
		j++;
	}

}

int main()
{
	int N;
	int *array;

	scanf("%d", &N);
	array = (int *)malloc(N * sizeof(int));

	for (int i = 0; i < N; i++)
	{
		scanf("%d", array + i);
	}

	bubblesort(array, N);

	for (int i = 0; i < 3; i++)
	{
		double_double(&array, &N); //N값도 계속 2배로
		bubblesort(array, N);

		for (int j = 0; j < N; j++)
		{
			printf("%d ", *(array + j));
		}

		printf("\n");
	}

	free(array);

	return 0;
}
