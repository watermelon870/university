#include <stdio.h>
#include <stdlib.h>

void push_back(int **a, int *size, int value) //뒤쪽에 원소 추가
{
	while (1)
	{
		if (*(*a + *(size + 1)) == NULL) //비주얼에서는 trash값으로 했는데 cspro에서는 NULL로
		{
			break;
		}
		*(size + 1) = *(size + 1) + 1;
	}

	//count 값은 실제로 할당된 배열의 크기 

	*(*a + *(size + 1)) = value;
	//다음으로 비어있는 배열에 값 삽입

	if ((*(size + 1) + 1) * 100 / *size >= 80)
	{
		*size = *size * 2;
		*a = (int *)realloc(*a, ((*size)) * sizeof(int));
		printf("크기 변경 %d -> %d \n", *size / 2, *size);
	}
	//80퍼센트 이상 할당시 배열크기 늘리기

}

void pop_back(int **a, int *size) //뒤쪽 원소 삭제
{
	int count = 0;
	while (1)
	{
		if (*(*a + count) == NULL)
		{
			break;
		}
		count++;
	}
	//count 값은 실재 할당된 배열의 크기

	*(size + 1) = count;

	*(*a + count - 1) = NULL;

	//마지막에 배정된 값 삭제

	if (*size > 5)  //배열 최소 크기 : 5
	{
		if ((count - 1) * 100 / (*size) <= 30)
		{
			*size = *size / 2;
			*a = (int *)realloc(*a, (*size) * sizeof(int));
			printf("크기 변경 %d -> %d \n", (*size) * 2, *size);
		}
	}
}

int main()
{
	int *arr;
	int *size;

	size = (int *)realloc(0, sizeof(int) * 2);  //size[0] = 전체 배열 크기, size[1] = 현재 사용중인 배열 크기
	*size = 5;
	*(size + 1) = 0;

	int choice = 0;
	int value = 0;

	arr = (int *)malloc(5 * sizeof(int)); // 초기size[0] = 5

	while (1)
	{
		scanf("%d", &choice);

		if (choice == 1)				//삽입, 80퍼 이상이면 배열크기 2배로
		{
			scanf("%d", &value);
			push_back(&arr, size, value);
		}
		else if (choice == 2)			//뒤에서 1개 삭제, 30퍼 이하면 배열크기 반으로
		{
			pop_back(&arr, size);
		}
		else if (choice == 3)			//내용출력
		{
			for (int j = 0; j <= *(size + 1); j++)
			{
				if (*(arr + j) == NULL)
				{
					break;
				}
				printf("%d ", *(arr + j));
			}
			printf("\n");
		}
		else if (choice == 4)			//종료
		{
			printf("종료 \n");
			break;
		}
		else
		{
			printf("1~4 사이의 숫자를 입력하시오 \n");
		}
	}

	free(arr);
	free(size);

	return 0;
}

