#include <stdio.h>
#include <stdlib.h>



int *get_next_process(int *prev_pointer, int size)
{
	int next_size;
	int *next_pointer = 0;

	if (size % 2 == 0) 
	{
		next_size = size / 2;
	}
	else
	{
		next_size = (size / 2) + 1;
	}
	//calculate next_size
	
	next_pointer = realloc(next_pointer, next_size * sizeof(int));
	//next_pointer memory allocation

	if (size % 2 == 0)
	{
		for (int i = 0; i < next_size; i++)
		{
			*(next_pointer + i) = *(prev_pointer + 2 * i) + *((prev_pointer + 2 * i) + 1);
			printf("%d ", *(next_pointer + i));
		}
		printf("\n");
	}
	else
	{
		for (int i = 0; i < next_size - 1; i++)
		{
			*(next_pointer + i) = *(prev_pointer + 2 * i) + *((prev_pointer + 2 * i) + 1);
			printf("%d ", *(next_pointer + i));
		}
		*(next_pointer + next_size - 1) = *(prev_pointer + size - 1);
		printf("%d \n", *(next_pointer + next_size - 1));
	}
	//generate next level

	free(prev_pointer);
	//free prev_pointer

	return next_pointer;
}

void swap(int *a, int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

int bubble_sort(int *a, int n)
{
	for (int j = 0; j < n - 1; j++)
	{
		for (int i = 1; i < n; i++)
		{
			if (*(a + i - 1) < *(a + i))
			{
				swap(a + i - 1, a + i);
			}
		}
	}
}



int main()
{
	int N;
	int Nconstant;
	int *num_of_box = 0;

	scanf("%d", &N);

	Nconstant = N;

	num_of_box = (int *)malloc(N * sizeof(int));
	
	for (int i = 0; i < N; i++)
	{
		scanf("%d", num_of_box + i);
	}
	
	bubble_sort(num_of_box, N);

	//no prob

	while (1)
	{
		if (Nconstant == 1)
		{
			break;
		}
		
		num_of_box = get_next_process(num_of_box, Nconstant);
		
		if (Nconstant % 2 == 0)
		{
			Nconstant = Nconstant / 2;
		}
		else
		{
			Nconstant = Nconstant / 2 + 1;
		}

	}

	free(num_of_box);
	//free num_of_box

	return 0;
}
