#include <stdio.h>

void upper_to_lower(char str[])
{
	int i = 0;

	while (1)
	{
		if (str[i] == NULL)
		{
			break;
		}

		if (65 <= str[i] && str[i] <= 90)   //&&연산자 주의. 65 <= str <= 90  안된다
		{
			printf("%c", str[i] + 32);
		}
		else 
		{
			printf("%c", str[i]);
		}
		i++;
	}
}

void lower_to_upper(char str[])
{
	int i = 0;

	while (1)
	{
		if (str[i] == NULL)
		{
			break;
		}

		if (97 <= str[i] && str[i] <= 122)
		{
			printf("%c", str[i] - 32);
		}
		else
		{
			printf("%c", str[i]);
		}
		i++;
	}
}

int main()
{
	char *s1 = "There's no Free Lunch";
	char *s2 = "123AbCdEfGh";

	upper_to_lower(s2);
	printf("\n");
	lower_to_upper(s2);
	printf("\n");

	upper_to_lower(s1);
	printf("\n");
	lower_to_upper(s1);
	printf("\n");

	return 0;
}
