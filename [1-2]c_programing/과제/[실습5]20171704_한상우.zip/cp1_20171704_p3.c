#include <stdio.h>
#include <stdlib.h>

void findans(int **matrix, int N, int M)
{

}

int main()
{
	int N, M;
	int **matrix;
	int i = 0;
	int j = 0;
	int *sum;

	scanf("%d %d", &N, &M); // N(height) * M(width)

	//자료형 배열이름[세로크기][가로크기]
	matrix = (int **)realloc(0, sizeof(int *) * N); // Marix의 전체 크기를 N으로 선언한다. (일차원으로 생각)
	matrix[0] = (int *)realloc(0, sizeof(int) * N*M); //*Matrix 에 M * N 할당. 자동적으로 Matrix[i]당 M개씩으로 나뉜다.
	for (int i = 1; i < N; i++)
	{
		matrix[i] = matrix[i - 1] + M;
	}//Matrix[1] ~ Matrix[N - 1]의 시작부분 정해주기
	//★M * N 2차원 배열 동적할당 완료 free 하려면 free(matrix[0]); 과 free(matrix); 해주면 완료!

	sum = (int *)realloc(0, sizeof(int) * N);
	//sum 동적할당
	for (int k = 0; k < N; k++)
	{
		*(sum + k) = 0;
	} //모든 sum에 0 대입

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++)
		{
			scanf("%d", &matrix[i][j]);
			sum[i] += matrix[i][j]; // sum은 한 가로 줄의 합
		}
	} //배열 입력 및 sum값 구하기

	for (int k = 0; k < N; k++)
	{
		if (sum[k] != M) //한 줄이 전부 1이지 않은 케이스 처리
		{
			while (1)
			{
					if (matrix[i][j] == 0 && matrix[i + 1][j] == 0)
					{
						break;
					}
					else
					{
						j++;
					}

				i++;

				if (i == N - 1)
				{
					break;
				}

			}
		}

		else        //한 줄이 전부 1인 특수 케이스 처리
		{
			j = M;
			break;
		}

	}

	printf("%d \n", j + 1); //정답 출력

	free(sum);
	free(matrix[0]);
	free(matrix);
	return 0;
}
