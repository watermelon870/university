#include <stdio.h>
#include <stdlib.h>

int string_length(char *st)
{
	int count = 0;
	while (1)
	{
		if (*(st + count) == NULL)
		{
			break;
		}
		count++;
	}

	return count;
}

int main()
{
	char s[] = "C is a high-level language";                //배열 크기를 비워두어 문자열 길이에 딱 맞는 배열이 생성된다.
	char *t = "C프로그래밍";

	/*배열을 사용한 경우  => 단지 배열의 시작주소를 나타내므로 하나의 변수가 아니다!*/
	printf("문자열 s의 길이 : %d\n", string_length(s));		//26출력(위에 저장된 배열의 문자 개수를 출력한다. \n(NULL)값은 포함되지 않는다)
	printf("sizeof(s)       : %d\n", (int)sizeof(s));		//27출력(단순히 배열의 문자 개수를 출력한다. 마지막 \0(NULL)값까지 포함한다)

															/*포인터를 사용한 경우 => 하나의 변수로서 별도의 저장공간을 갖는다*/
	printf("문자열 t의 길이 : %d\n", string_length(t));		//11출력(위에 저장된 배열의 문자 개수를 출력한다.)
	printf("sizeof(t)       : %d\n", (int)sizeof(t));		//4출력 (포인터 변수 t의 크기를 출력한다.) 

	return 0;
}
