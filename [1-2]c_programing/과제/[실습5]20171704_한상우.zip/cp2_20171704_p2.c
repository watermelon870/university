#include <stdio.h>
#include <stdlib.h>

int main()
{
	char s[16];
	int i = 0;
	int j = 16;

	scanf("%16s", s);

	while (1)
	{
		if (s[i] == NULL)
		{
			break;
		}

		if ('0' <= s[i] && s[i] <= '9')
		{
			j--;
		}

		i++;
	}

	j = 16 - j;

	if (s[j] == '\0')	//숫자로만 입력 됨
	{
		if (j < 4)
		{
			printf("%s \n", s);
		}
		else if (j < 7)
		{
			printf("%.2sK \n", s);
		}
		else if (j < 10)
		{
			printf("%.2sM \n", s);
		}
		else if (j < 13)
		{
			printf("%.2sG \n", s);
		}
		else if (j < 16)
		{
			printf("%.2sT \n", s);
		}
		else
		{
			printf("%.1sP \n", s);
		}

	}
	else				//줄여진 표현및 소문자
	{
		printf("%s \n", s);
	}

	return 0;
}
