#include <stdio.h>
#include <stdlib.h>

int main()
{
	char str[100];
	int count = 0; //space 개수

	fgets(str, sizeof(str), stdin);

	int i = 0;

	while (1)
	{
		if (str[i] == NULL)
		{
			break;
		}

		if (str[i] == ' ')
		{
			count++;
		}

		if (str[i] == ' ' && str[i + 1] == ' ') // ' ' 3개 이상도 적용 가능하다
		{
			count = count - 1;
		}

		i++;
	}

	if (str[0] == ' ') //시작에 스페이스 무시하기
	{
		count = count - 1;
	}

	if (str[i - 2] == ' ') //끝에 스페이스 무시하기, i - 2 가 맞다
	{
		count = count - 1;
	}

	printf("%d \n", count + 1);

	return 0;
}
