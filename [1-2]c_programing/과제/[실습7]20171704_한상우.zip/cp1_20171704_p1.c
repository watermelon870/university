#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum Date { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday };

enum Date getDate(int y, int m, int d);

char* getDay(enum Date currDate);

int main()
{
	int y, m, d;


	scanf("%d", &y);
	scanf("%d", &m);
	scanf("%d", &d);

	typedef struct {
		int year, month, day;
		enum Date date;
		char* dateString;
	}Calendar;

	Calendar you = { y, m, d, getDate(y, m, d), getDay(getDate(y, m, d)) };

	printf("%s \n", you.dateString);

	return 0;
}

enum Date getDate(int y, int m, int d) //enum까지 붙여줘야한다
{
	return (y + y / 4 - y / 100 + y / 400 + (13 * m + 8) / 5 + d) % 7;
}

char* getDay(enum Date currDate)  //여기도 enum까지 붙여줘야 한다
{
	switch (currDate) {
	case 0: return "Sunday"; break;
	case 1: return "Monday"; break;
	case 2: return "Tuesday"; break;
	case 3: return "Wednesday"; break;
	case 4: return "Thursday"; break;
	case 5: return "Friday"; break;
	case 6: return "Saturday"; break;
	default: return 0;

	}
}
