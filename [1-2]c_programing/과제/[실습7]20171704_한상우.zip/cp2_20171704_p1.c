#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef float* Vector_Comp;
typedef float Comp;
typedef double VectorSize;
typedef double Distance;
typedef double Scalar;								//여러개로 겹쳐서 선언 가능
typedef struct {
	Vector_Comp comps;
	int vec_size;
}Vector;

VectorSize vSize(Vector v)                           //구조체로 함수에 전달 가능해서 매우 편리
{
	double inside = 0;
	for (int i = 0; i < v.vec_size; i++)
	{
		inside += v.comps[i] * v.comps[i];
	}

	return sqrt(inside);
}

Distance DistVector(Vector v1, Vector v2)
{
	double inside = 0;
	for (int i = 0; i < v1.vec_size; i++)
	{
		inside += (v1.comps[i] - v2.comps[i]) * (v1.comps[i] - v2.comps[i]);
	}

	return sqrt(inside);
}

Scalar InnerProduct(Vector v1, Vector v2)
{
	double inside = 0;
	for (int i = 0; i < v1.vec_size; i++)
	{
		inside += v1.comps[i] * v2.comps[i];
	}

	return inside;
}

int main()
{
	Vector v1;
	printf("Size of vector v1 : ");
	scanf("%d", &v1.vec_size);
	v1.comps = (Vector_Comp)malloc(sizeof(Comp) * v1.vec_size);

	printf("vector 1 : ");
	for (int i = 0; i < v1.vec_size; i++)
	{
		scanf("%f", &v1.comps[i]);
	}

	Vector v2;
	printf("Size of vector v2 : ");
	scanf("%d", &v2.vec_size);
	v2.comps = (Vector_Comp)malloc(sizeof(Comp) * v2.vec_size);

	printf("vector 2 : ");
	for (int i = 0; i < v2.vec_size; i++)
	{
		scanf("%f", &v2.comps[i]);
	}

	printf("---------------------------------\n");
	printf("Size of v1 = %.2lf \n", vSize(v1));
	printf("Size of v1 = %.2lf \n", vSize(v2));

	if (v1.vec_size == v2.vec_size)
	{
		printf("Distance v1, v2 = %lf \n", DistVector(v1, v2));
		printf("Inner Produce v1 * v2 = %lf \n", InnerProduct(v1, v2));
	}

	return 0;
}

