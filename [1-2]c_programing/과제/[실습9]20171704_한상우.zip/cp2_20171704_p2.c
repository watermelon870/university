#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	int type;
	char name[20];
	union utemp {
		int i;
		float f;
		double d;
	}u;
}stemp;

void power(stemp *s)
{
	if (s->type == 1)
	{
		s->u.i = s->u.i * s->u.i;
	}
	else if (s->type == 2)
	{
		s->u.f = s->u.f * s->u.f;
	}
	else
	{
		s->u.d = s->u.d * s->u.d;
	}
}

int main()
{
	int n;
	printf("Number of Iterations : ");
	scanf("%d", &n);

	stemp* s;
	s = (stemp *)malloc(sizeof(stemp) * n);

	for (int j = 0; j < n; j++)
	{
		printf("Type [1 for int, 2 for float, 3 for double] : ");
		scanf("%d", &s[j].type);                                  //�̷� ǥ���� �����ϰ�

		if (s[j].type == 1)
		{
			printf("Enter an integer value : ");
			scanf("%d", &(s + j)->u.i);
			strcpy((s + j)->name, "integer");                     //�̷� ǥ���� �����ϴ�
		}
		else if (s[j].type == 2)
		{
			printf("Enter an float value : ");
			scanf("%f", &(s + j)->u.f);
			strcpy((s + j)->name, "float");
		}
		else if (s[j].type == 3)
		{
			printf("Enter an double value : ");
			scanf("%lf", &(s + j)->u.d);
			strcpy((s + j)->name, "double");
		}
		else
		{
			printf("Enter proper number! \n");
			j--;
		}

		power(s + j);

	}

	printf("----------------Result----------------\n");


	for (int j = 0; j < n; j++)
	{

		if ((s + j)->type == 1)
		{
			printf("%-10s: %d \n", s[j].name, s[j].u.i);              //(s + j)->u.i �̷��Ծ��ϱ� �̻��Ѱ�.. �������ΰ�?

		}
		else if ((s + j)->type == 2)
		{
			printf("%-10s: %.4f \n", s[j].name, s[j].u.f);
		}
		else
		{
			printf("%-10s: %.4lf \n", s[j].name, s[j].u.d);

		}

	}

	free(s);
	return 0;
}