#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
	double x;	//구의 중심 x좌표
	double y;	//구의 중심 y좌표
	double z;	//구의 중심 z좌표
	double r;	//구의 반지름
}SPHERE;

double get_mean(double x, double y)
{
	return ((x - y) * (x - y));
}

double get_square(double x, int n)
{
	for (int i = 1; i < n; i++)
	{
		x = x * x;
	}

	return x;
}

double Distance(SPHERE* a, SPHERE* b)	//중심사이 거리
{
	return sqrt(get_mean(a->x, b->x) + get_mean(a->y, b->y) + get_mean(a->z, b->z));           //a.x나 b.x가 아님에 주의한다
}

double CrossSectionArea(SPHERE* a, SPHERE* b)	//단면적의 합
{
	return ((3.14) * (get_square(a->r, 2) + get_square(b->r, 2)));
}

double SurfaceArea(SPHERE* a, SPHERE* b)	//겉넓이의 합
{
	return ((4 * 3.14) * (get_square(a->r, 2) + get_square(b->r, 2)));
}


double Volume(SPHERE* a, SPHERE* b)		//부피의 합
{
	return 4 * 3.14 * ((a->r * a->r * a->r) + (b->r * b->r * b->r)) / 3;
}

int main()
{
	SPHERE a;
	SPHERE b;

	printf("Type First Sphere Corrdinate : ");
	scanf("%lf %lf %lf", &a.x, &a.y, &a.z);
	printf("Type First Sphere Radius : ");
	scanf("%lf", &a.r);

	printf("Type Second Sphere Corrdinate : ");
	scanf("%lf %lf %lf", &b.x, &b.y, &b.z);
	printf("Type Second Sphere Radius : ");
	scanf("%lf", &b.r);

	printf("\n");

	if (Distance(&a, &b) < (a.r + b.r))		//두 구가 겹치는 경우
	{
		printf("Sum of Volume : %.2lf \n", Volume(&a, &b));
	}
	else if (Distance(&a, &b) == (a.r + b.r)) //두 구가 접하는 경우 
	{
		printf("Sum of SurfaceArea : %.2lf \n", SurfaceArea(&a, &b));
	}
	else									//두 구가 떨어져 있는 경우
	{
		printf("Sum of Cross Section Area : %.2lf\n", CrossSectionArea(&a, &b));
	}

	return 0;
}
