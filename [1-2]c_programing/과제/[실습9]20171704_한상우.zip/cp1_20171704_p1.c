#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char dept_name[25];
	int dept_no;
}dept;

enum Gender { Male = 0, Female };

typedef struct {
	int employee_id;
	char name[25];
	enum Gender gender;
	dept department;
	double salary;
}employee_data;

int search(employee_data *e, int num, int keyword)
{

	for (int i = 1; i <= num; i++)
	{
		if (keyword == (e + i)->employee_id)
		{
			return i;
		}
	}

	return 0;
}

employee_data update(employee_data e, int n)
{

}

int main()
{
	int key = 0;
	char y_n;           //y�� n�� �޾Ƶ���
	char **temp;
	employee_data* all_data;

	FILE *fp1 = fopen("17_input.txt", "r");

	int n = 0;
	fscanf(fp1, "%d", &n);

	all_data = (employee_data *)malloc(sizeof(employee_data) * 50);

	temp = (char **)malloc(sizeof(char *) * 50);
	*temp = (char *)malloc(sizeof(char) * 70);
	for (int i = 1; i < 50; i++)
	{
		*(temp + i) = *(temp + i - 1) + 70;
	}
	//���Ͽ��� �ִ� 50��, �� �ٴ� 70�ھ� ���� ������ �������迭 �����


	for (int i = 0; i <= n; i++)
	{
		fgets(*(temp + i), sizeof(*(temp + i)), fp1);           // \n���� ���ԵǼ� ������
															  //printf("%s", *(temp + i));

		if (i > 0)
		{
			int id;
			char first_n[15];
			char last_n[15];
			char gend[8];
			char dep[25];
			int depn;
			double sal;
			//�ӽ������ ������
			sscanf(*(temp + i), "%d %*2c %s %s %*2c %s %*2c %s %*2c %d %*2c %lf", &id, first_n, last_n, gend, dep, &depn, &sal);
			//printf("id : %d\nname : %s %s\ngender : %s\ndep : %s\ndepn : %d\nsal : %lf\n", id, first_n, last_n, gend, dep, depn, sal);

			char full_n[26];
			strcpy(full_n, strcat(strcat(first_n, " "), last_n));

			(all_data + i)->employee_id = id;//id����
			strcpy((all_data + i)->name, full_n);//name����
			if (strcmp(gend, "Male") == 0)
			{
				(all_data + i)->gender = Male;
			}
			else
			{
				(all_data + i)->gender = Female;
			}//gender����
			strcpy((all_data + i)->department.dept_name, dep);//dept name����
			(all_data + i)->department.dept_no = depn;
			(all_data + i)->salary = sal;

			//printf("%d / %s / %d / %s / %d / %lf \n", (all_data + i)->employee_id, (all_data + i)->name, (all_data + i)->gender, (all_data + i)->department.dept_name, (all_data + i)->department.dept_no, (all_data + i)->salary);
		}

	}

	while (1)
	{
	
		printf("Employee ID : ");
		scanf("%d", &key);

		if (search(all_data, n, key) == 0)
		{
			printf("No employee\n");
			printf("Continue? (y/n) : ");
			scanf("%c", &y_n);
		}
		else
		{
			int i;
			i = search(all_data, n, key);
			printf("----------Employee Data----------\n");
			printf("%d / %s / %d / %s / %d / %lf \n", (all_data + i)->employee_id, (all_data + i)->name, (all_data + i)->gender, (all_data + i)->department.dept_name, (all_data + i)->department.dept_no, (all_data + i)->salary);

			printf("Continue? (y/n) : ");
			scanf("%c", &y_n);

		}

		

		if (y_n == 'y')
		{
			key++;
		}
		else
		{
			break;
		}

	}


	fclose(fp1);
	free(*temp);
	free(temp);
	return 0;
}