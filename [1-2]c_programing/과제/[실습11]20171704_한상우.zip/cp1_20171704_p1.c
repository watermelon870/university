#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* sptr;

typedef struct
{
	int count;
	sptr top;
}STACK;

typedef struct node
{
	int data;
	sptr link;
}STACK_NODE;

void Exit(STACK* pStack)
{
	STACK_NODE* curr = pStack;
	STACK_NODE* prev;
	while (curr->link != NULL)
	{
		prev = curr;
		curr = curr->link;
		free(prev);
	}
	free(curr);
	//printf("free done!\n");
}

void Push(STACK* pStack)
{
	int data;
	STACK_NODE* pNew = (STACK_NODE*)malloc(sizeof(STACK_NODE));
	printf("Input data > ");
	scanf("%d", &data);

	pNew->data = data;
	pNew->link = pStack->top;
	pStack->top = pNew;
	pStack->count++;

	//printf("Push success!\n");
}

void Pop(STACK* pStack)
{
	int dataOut;
	STACK_NODE* pDlt;

	if (pStack->top == NULL)
	{
		printf("All data Poped! \n");
		return;
	}

	pDlt = pStack->top;
	dataOut = pDlt->data;
	printf("Poped data : %d \n", dataOut);

	pStack->top = pStack->top->link;
	pStack->count--;

	free(pDlt);
	//printf("Pop success!\n");

}

void PrintAll(STACK* pStack)
{
	STACK_NODE* curr = pStack;
	while (curr->link != NULL)
	{
		curr = curr->link;
		printf("%d ", curr->data);
	}
	printf("Stack Level : %d \n", pStack->count);
}

int main()
{
	STACK* pStack = (STACK*)malloc(sizeof(STACK));
	pStack->top = NULL;
	pStack->count = 0;

	int what_to_do = 0;

	printf("****** MENU ******\n");
	printf("* 0 : EXIT       *\n");
	printf("* 1 : Push       *\n");
	printf("* 2 : Pop        *\n");
	printf("* 3 : Print All  *\n");
	printf("******************\n");

	while (1)
	{
		printf("Select > ");
		scanf("%d", &what_to_do);

		if (what_to_do == 0)
		{
			Exit(pStack);
			break;
		}
		else if (what_to_do == 1)
		{
			Push(pStack);
		}
		else if (what_to_do == 2)
		{
			Pop(pStack);
		}
		else if (what_to_do == 3)
		{
			PrintAll(pStack);
		}
		else
		{
			printf("put in number 0 ~ 3\n");
		}
	}

	return 0;
}
