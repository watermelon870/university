	#define _CRT_SECURE_NO_WARNINGS
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>

	typedef struct node
	{
		int data;
		struct node* next;
	}QUEUE_NODE;

	typedef struct
	{
		QUEUE_NODE* front;
		int count;
		QUEUE_NODE* rear;
	}QUEUE;

	void Exit(QUEUE* pQueue)
	{
		QUEUE_NODE* curr = pQueue->front;
		QUEUE_NODE* prev;
		if (pQueue->count == 0)
		{

		}
		else
		{
			while (curr != pQueue->rear)  //printAll 함수와 약간 다르게 해야한다. 한 부분 앞에서 멈추고 while문 나와서 curr free해주기
			{
				prev = curr;
				curr = curr->next;
				free(prev);
			}
			free(curr);
		}

		printf("free done!\n");

	}

	void Enqueue(QUEUE* pQueue)
	{
		int data;
		printf("Input data > ");
		scanf("%d", &data);

		QUEUE_NODE* newNode = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE));
		newNode->data = data;
		newNode->next = NULL;

		if (pQueue->count == 0)
		{
			pQueue->front = newNode;
		}
		else
		{
			pQueue->rear->next = newNode;
		}
		pQueue->count++;
		pQueue->rear = newNode;  //※이 부분이 필요한 이유 => count가 0일 때 front와 rear연결, count가 1이상 일때 rear위치 갱신

		printf("Enqueue success! \n");
	}

	void Dequeue(QUEUE* pQueue)
	{
		int dataOut = 0;
		QUEUE_NODE* pDlt = pQueue->front;
		if (pQueue->count == 0)
		{
			printf("Error:: Empty Queue! \n");
			return;
		}

		dataOut = pDlt->data;
		pQueue->front = pDlt->next;
		pQueue->count--;
		free(pDlt);


		printf("Dequeued data : %d\n", dataOut);
	}

	void PrintAll(QUEUE* pQueue)
	{
		QUEUE_NODE* curr = pQueue->front;
		if (pQueue->count == 0)
		{

		}
		else
		{
			while (curr != pQueue->rear->next)
			{
				printf("%d ", curr->data);
				curr = curr->next;
			}
		}

		printf("\nQueue Level : %d\n", pQueue->count);
	}

	int main()
	{
		QUEUE* pQueue = (QUEUE*)malloc(sizeof(QUEUE));
		pQueue->front = NULL;
		pQueue->count = 0;
		pQueue->rear = NULL;

		printf("****** MENU ******\n");
		printf("* 0 : EXIT       *\n");
		printf("* 1 : Enqueue    *\n");
		printf("* 2 : Dequeue    *\n");
		printf("* 3 : Print All  *\n");
		printf("******************\n");

		int what_to_do = 0;

		while (1)
		{
			printf("Select > ");
			scanf("%d", &what_to_do);

			if (what_to_do == 0)
			{
				Exit(pQueue);
				break;
			}
			else if (what_to_do == 1)
			{
				Enqueue(pQueue);
			}
			else if (what_to_do == 2)
			{
				Dequeue(pQueue);
			}
			else if (what_to_do == 3)
			{
				PrintAll(pQueue);
			}
			else
			{
				printf("Error::select proper number!\n");
			}
		}

		return 0;
	}
