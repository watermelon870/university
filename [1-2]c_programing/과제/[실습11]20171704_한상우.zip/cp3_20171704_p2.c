#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
	char* command;                 //이렇게만 해놔도 괜찮다, char command[10];하면 l-value아니라서 에러
	struct node* next;
}QUEUE_NODE;

typedef struct
{
	QUEUE_NODE* front;
	int count;
	QUEUE_NODE* rear;
}QUEUE;

int CheckCommand(char* command)
{
	if (strcmp(command, "history") == 0 || strcmp(command, "h") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "quit") == 0 || strcmp(command, "q") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "mkdir") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "cd") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "help") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "dir") == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void EnqueueCommand(QUEUE* pQueue, char* dataIn)
{
	QUEUE_NODE* newNode = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE));
	newNode->command = dataIn;
	newNode->next = NULL;

	if (pQueue->count == 0)
	{
		pQueue->front = newNode;
	}
	else
	{
		pQueue->rear->next = newNode;
	}

	pQueue->count++;
	pQueue->rear = newNode;
	//printf("enqueue success!\n");

}

int DequeuePrint(QUEUE* pQueue, char** dataOut)
{
	if (pQueue->count == 0)
	{
		return 0;
	}
	QUEUE_NODE* dltNode;
	dltNode = pQueue->front;
	*dataOut = pQueue->front->command;

	if (pQueue->count == 1)                     //count == 1, count > 1 둘도 다르게 처리해줘야한다
	{
		pQueue->rear = pQueue->front = NULL;
	}
	else
	{
		pQueue->front = pQueue->front->next;
	}

	free(dltNode);
	pQueue->count--;

	//printf("Dequeue success!\n");
	return 1;
}

void freeAll(QUEUE* pQueue)
{
	QUEUE_NODE* curr = pQueue->front;
	QUEUE_NODE* prev;
	while (curr != pQueue->rear)
	{
		prev = curr;
		curr = curr->next;
		free(prev);
	}
	free(curr);
}

/*
void printAll(QUEUE* queue)
{
	if (queue->count == 0)
	{
	}
	else
	{
		QUEUE_NODE* curr = queue->front;
		while (curr != queue->rear->next)       //이 부분 조심하기
		{
			printf("%s ", curr->command);
			curr = curr->next;
		}
	}
	printf("\nQueue Level : %d\n", queue->count);

}
*/

int main()
{
	char **command;  //맨날 쳐 바뀌니까 이렇게 해 보자. 왜 그냥 command[10];으로 하면 다 바뀌는거지..???
	command = (char**)malloc(sizeof(char*) * 10);
	command[0] = (char*)malloc(sizeof(char) * 10 * 100);
	for (int i = 1; i < 10; i++)
	{
		command[i] = command[i - 1] + 100;
	}

	int j = 0;

	QUEUE* pQueue = (QUEUE*)malloc(sizeof(QUEUE));
	pQueue->front = NULL;
	pQueue->count = 0;
	pQueue->rear = NULL;

	while (1)
	{

		printf(">>");
		scanf("%s", command[j]);

		if (CheckCommand(command[j]) == 1)
		{

			if (strcmp(command[j], "history") == 0 || strcmp(command[j], "h") == 0)
			{
				char* dataOut;

				while (DequeuePrint(pQueue, &dataOut))
				{
					printf("%s\n", dataOut);          //해당 node의 command 출력
				}
			}
			else if (strcmp(command[j], "quit") == 0 || strcmp(command[j], "q") == 0)
			{
				freeAll(pQueue);
				break;
			}
			else
			{
				EnqueueCommand(pQueue, command[j]);
				printf("[Valid] %s\n", command[j]);
			}

			j++;
		}
		else
		{
			printf("[Invalid]\n");
		}

	}

	free(command[0]);
	free(command);

	return 0;
}
