#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
	char* command;                 //이렇게만 해놔도 괜찮다, char command[10];하면 l-value아니라서 에러
	struct node* next;
}QUEUE_NODE;

typedef struct
{
	QUEUE_NODE* front;
	int count;
	QUEUE_NODE* rear;
}QUEUE;

int CheckCommand(char* command)
{
	if (strcmp(command, "history") == 0 || strcmp(command, "h") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "quit") == 0 || strcmp(command, "q") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "mkdir") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "cd") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "help") == 0)
	{
		return 1;
	}
	else if (strcmp(command, "dir") == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void EnqueueCommand(QUEUE* pQueue, char* dataIn)
{
	QUEUE_NODE* newNode = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE));
	newNode->command = dataIn;
	newNode->next = NULL;

	if (pQueue->count == 0)
	{
		pQueue->front = newNode;
	}
	else
	{
		pQueue->rear->next = newNode;
	}

	pQueue->count++;
	pQueue->rear = newNode;
	//printf("enqueue success!\n");

}

void freeAll(QUEUE* pQueue)
{
	QUEUE_NODE* curr = pQueue->front;
	QUEUE_NODE* prev;
	while (curr != pQueue->rear)
	{
		prev = curr;
		curr = curr->next;
		free(prev);
	}
	free(curr);
}

int main()
{
	char* command = (char*)malloc(sizeof(char) * 10);      //동적할당해주기
	QUEUE* pQueue = (QUEUE*)malloc(sizeof(QUEUE));

	pQueue->front = NULL;
	pQueue->count = 0;
	pQueue->rear = NULL;

	while (1)
	{
		printf(">>");
		scanf("%s", command);

		if (CheckCommand(command) == 1)
		{

			if (strcmp(command, "history") == 0 || strcmp(command, "h") == 0)
			{
				printf("queue count = %d\n", pQueue->count);
			}
			else if (strcmp(command, "quit") == 0 || strcmp(command, "q") == 0)
			{
				freeAll(pQueue);
				break;
			}
			else
			{
				EnqueueCommand(pQueue, command);
				printf("[Valid] %s\n", command);
			}

		}
		else
		{
			printf("[Invalid]\n");
		}
	}

	free(command);

	return 0;
}
