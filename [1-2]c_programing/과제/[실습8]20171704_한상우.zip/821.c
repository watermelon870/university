#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	float price;//����
	float number;//����
}Buying;

Buying getAverage(Buying* pBuying, int n)
{
	Buying average;

	average.number = 0;
	average.price = 0;           //�׻� += �� ���� �ʱⰪ 0���� �� �ְ� �������

	for (int i = 0; i < n; i++)
	{
		average.number += pBuying[i].number;
		average.price += pBuying[i].price;
	}

	average.number = average.number / n;
	average.price = average.price / n;

	return average;
}

int main()
{
	int N = 0;
	scanf("%d", &N);

	Buying* bought;
	bought = (Buying*)malloc(sizeof(Buying) * N);

	for (int i = 0; i < N; i++)
	{
		scanf("%f %f", &bought[i].price, &bought[i].number);          //bought[i].price�� ���� ��Ÿ�� �� �ִ�
	}

	printf("%.2f %.2f \n", getAverage(bought, N).price, getAverage(bought, N).number);

	free(bought);

	return 0;
}