#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	int numerator;//����
	int denominator;//�и�
}FRACTION;

void multFr(FRACTION* pFr1, FRACTION* pFr2, FRACTION* pRES2)
{
	pRES2->numerator = pFr1->numerator * pFr2->numerator;
	pRES2->denominator = pFr1->denominator * pFr2->denominator;
}

int main()
{
	FRACTION Fr1;
	FRACTION Fr2;
	FRACTION RES2;

	FRACTION* pFr1 = &Fr1;
	FRACTION* pFr2 = &Fr2; 
	FRACTION* pRES2 = &RES2;

	printf("Fr1 numerator :   \t");
	scanf("%d", &Fr1.numerator);
	printf("Fr1 denominator :   \t");
	scanf("%d", &Fr1.denominator);
	printf("Fr1 :\t\t      %d/%d \n", pFr1->numerator, pFr1->denominator);

	printf("Fr2 numerator :   \t");
	scanf("%d", &pFr2->numerator);                       //�翬�� �̷��Ե� �޾� �� �� �ִ�
	printf("Fr2 denominator :   \t");
	scanf("%d", &pFr2->denominator);
	printf("Fr2 :\t\t      %d/%d \n", pFr2->numerator, pFr2->denominator);

	multFr(pFr1, pFr2, pRES2);

	printf("\n%d/%d * %d/%d = %d/%d \n", pFr1->numerator, pFr1->denominator, pFr2->numerator, pFr2->denominator, pRES2->numerator, pRES2->denominator);

	return 0;
}