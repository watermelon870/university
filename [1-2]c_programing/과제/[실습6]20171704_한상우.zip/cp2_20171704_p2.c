#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char** my_strsplit(char* str, char* deli)
{
	char **save;
	int count = 0;
	int count1 = 1;
	int count2 = 0;

	save = (char **)malloc(sizeof(char *) * 10); //�ִ� 10�������� �ɰ����� ����		
	save[0] = (char *)malloc(sizeof(char) * (10 * 20));
	for (int i = 0; i < 10; i++)
	{
		save[i + 1] = save[i] + 20;
	}
	//save[0] = str;save[1] = deli;
	save[0] = strtok(str, deli);




	for (; save != '\0' ;)
	{
		printf("%s\n", save[count]);
		count++;
		save[count] = strtok(NULL, deli);
	}

	return save;
	free(save);
	free(save[0]);
}

int main()
{
	char str1[50];
	char *str2;

	char deli1[25];
	char *deli2;

	char *print;
	print = (char *)malloc(sizeof(char) * 10);

	printf("Input string : ");
	gets(str1);
	str2 = (char *)realloc(0, sizeof(char) * strlen(str1));
	strcpy(str2, str1);

	printf("Input delimiter : ");
	gets(deli1);
	deli2 = (char *)realloc(0, sizeof(char) * strlen(deli1));
	strcpy(deli2, deli1);

	print = my_strsplit(str2, deli2);

	printf("yess\n");

	while (print != '\0')
	{
		printf("%s\n", print++);
	}

	printf("yess\n");

	free(print);
	free(str2);
	free(deli2);

	return 0;
}