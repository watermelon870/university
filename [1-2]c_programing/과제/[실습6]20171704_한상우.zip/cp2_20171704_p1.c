#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void strPk(char* src, char* dst) //알파벳 아닌 값만 dst에 저장
{
	int count = 0;
	int i = 0;

	strcpy(dst, src);

	while (1)
	{
		if (src[i] == '\0')
		{
			break;
		}

		if ('a' <= src[i] && src[i] <= 'z')
		{
			count++;
		}
		else if ('A' <= src[i] && src[i] <= 'Z')
		{
			count++;
		}
		else
		{
			count = count;
		}
		i++;
	}

	dst[count] = '\0';

	i = 0;
	count = 0;

	while (1)
	{
		if (src[i] == '\0')
		{
			break;
		}

		if ('a' <= src[i] && src[i] <= 'z')
		{
			dst[count] = src[i];
			count++;
		}
		else if ('A' <= src[i] && src[i] <= 'Z')
		{
			dst[count] = src[i];
			count++;
		}
		else
		{
			count = count;
		}
		i++;
	}

}

int strCmpPk(char* s1, char* s2)//s1, s2를 비교
{
	return strcmp(s1, s2);
}

int main()
{
	char *s1;
	char *s2;
	char *dst1;
	char *dst2;

	s1 = (char *)realloc(0, sizeof(char) * 50);
	s2 = (char *)realloc(0, sizeof(char) * 50);
	dst1 = (char *)realloc(0, sizeof(char) * 50);
	dst2 = (char *)realloc(0, sizeof(char) * 50);

	printf("First string : ");
	gets(s1);
	printf("Second string : ");
	gets(s2);

	strPk(s1, dst1);
	strPk(s2, dst2);

	if (strCmpPk(dst1, dst2) == 0)			//같을 때
	{
		printf("string1 == string2 \n");
	}
	else if (strCmpPk(dst1, dst2) < 0)	//s1 < s2 ex> aac, abc
	{
		printf("string1 < string2 \n");
	}
	else								//s1 > s2
	{
		printf("string1 > string2 \n");
	}

	return 0;
}
