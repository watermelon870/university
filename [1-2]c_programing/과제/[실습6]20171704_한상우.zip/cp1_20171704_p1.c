#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void split_string(char *str, char *string_1, char *string_2)
{
	strcpy(string_1, str);
	string_1[strlen(str) / 2] = NULL;
	strcpy(string_2, str + (strlen(str) / 2));
	string_2[strlen(str) / 2] = NULL;

}

int main()
{
	char str[50];
	char string_1[25];
	char string_2[25];

	printf("input str : ");
	gets(str);					//fgets�� �ָ��ؼ� gets�� �ּ��ε�

	if (strlen(str) % 2 == 0)
	{
		split_string(str, string_1, string_2);
	}
	else
	{
		str[strlen(str) - 1] = NULL;		 //Ȧ���϶� ������ ����

		split_string(str, string_1, string_2);
	}

	printf("[%s] - > [%s]  [%s] \n", str, string_1, string_2);

	return 0;
}