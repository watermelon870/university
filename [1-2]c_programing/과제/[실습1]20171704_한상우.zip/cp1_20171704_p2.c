#include<stdio.h>

int main()
 {
	double a, b, c, d;
	double *pa, *pb, *pc, *pd;
	pa = &a, pb = &b, pc = &c, pd = &d;
			
	
	scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
	
	if (*pa != *pc) {
		printf("1");
		
	}
	else {
		if (*pb == *pd) {
			printf("oo");
			
		}
		else {
			printf("0");
			
		}
		
	}
	
	printf("\n");
	
	return 0;
}
