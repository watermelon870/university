#include<stdio.h>

int main()
{
	int a, b, c;
	int* pa; 
	int* pb;
	int* pc;
	scanf("%d%d%d", &a, &b, &c);
    pa = &a; pb = &b; pc = &c;
	int* max;
	int* min;

	max = pa;
	min = pa;

	if(*pa < *pb){
		max = pb;
	}
	else {
		min = pb;
	}

	if (*max < *pc) {
		max = pc;
	}
	else {
		if (*min > *pc) {
			min = pc;
		}
	}
	
	printf("%d %d \n", *min, *max);
	printf("%d %d \n", min, max);
	return 0;
}

